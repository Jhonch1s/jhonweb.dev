# Checklist de publicación — Jhon Guimaraens

Revisión del 2026-10-01. Dominio elegido: `jhonweb.dev`; registro y publicación pendientes.

## Contenido

- [x] Nombre, servicios y zona verificados. No se publican precios, horarios ni mapa.
- [x] WhatsApp, correo y GitHub coinciden con los datos proporcionados por Jhon.
- [x] No quedan textos de muestra; las demos identifican sus datos como ficticios.
- [x] Jhon pidió pasar a publicación y confirmó autorización para exhibir la marca e imagen de Jair.

## Experiencia

- [x] Revisado en móvil y escritorio en la versión compilada.
- [x] Enlaces y botones tienen foco visible; existe enlace para saltar al contenido.
- [x] Contraste y tamaños de texto revisados visualmente.
- [x] No hay formularios.
- [ ] Verificar enlaces externos y navegación completa después del despliegue. La portada y ambas demos cargan sin errores de consola en la vista previa local.

## SEO y rendimiento

- [x] `title` y meta description de la portada configurados.
- [x] Un `h1` y jerarquía semántica revisados.
- [x] Canonical, favicon e imagen social absoluta configurados para `jhonweb.dev`.
- [x] `robots.txt` y sitemap configurados para la portada; las demos llevan `noindex`.
- [x] Imágenes dimensionadas, comprimidas y con `alt` según su función decorativa o informativa.
- [x] No se usa schema por ahora; no hay datos adicionales confirmados que lo justifiquen.
- [x] Revisión inicial de peso completada: portada estática y demos cargadas por separado. Medir la URL pública tras el despliegue.

## Dominio y entrega

- [ ] Registrar `jhonweb.dev` a nombre de Jhon.
- [ ] Registrar DNS y correo existentes antes de conectar el dominio.
- [ ] Verificar HTTPS y redirección principal después de conectar el dominio.
- [ ] Guardar copia final del sitio compilado y código fuente.
- [ ] Confirmar cómo se administrarán futuras actualizaciones.
- [ ] Registrar fecha y URL de publicación.

